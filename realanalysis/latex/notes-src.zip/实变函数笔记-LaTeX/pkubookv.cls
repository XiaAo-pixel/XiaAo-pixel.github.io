% -----------------------------------------------------------------------------
% pkubookv.cls —— 北京大学风格的 ElegantBook 封套类（VividBook 版）
%
% 以 ElegantLaTeX 的 ElegantBook 为基准，视觉版式参照 Azure1210/VividBooK，
% 并沿用 rexera/minimalist-pku-beamer-2026 的北大配色与字体回退：
%   1. 配色：ElegantBook 各主题色整体映射到北大官方色系（燕园红 peking 为主色，
%      peking_blue / peking_orange / peking_gold 为定理盒辅助色）；
%   2. 页眉页脚：页眉右上角放置北京大学校徽（Figures/PKU-emblem-names.png，
%      与 Beamer 模板 frametitle 右上角校徽同源同思路），页眉下划线与页码改用
%      燕园红；
%   3. 封面与章首页：封面沿用 pkubook 版，章首页仿 VividBooK ——
%      · 封面为“全幅校园照片 + 象牙色标题板”（与 pkubook 版一致），照片用
%        \coverphoto 指定，未指定时取 Figures/cover.jpg（建议与 A4 同比例）；
%        若使用 \cover{完整封面图} 则仍走 ElegantBook 原版封面；
%      · 每章首页顶部为全幅横幅照片（2:1），章号与章名放在横贯照片下缘的
%        白色半透明圆角标题条中，照片用 \chapterimage 指定，未指定时取
%        Figures/chapter1.jpg；
%      · 目录页同样是带横幅照片的章首页，可在 \tableofcontents 前用
%        \chapterimage 换图；
%   4. 字体：完整移植 Beamer 模板的中文回退机制 —— ctex 以 fontset=none 载入，
%      macOS 使用 Songti SC，其余环境（Windows/Linux/Overleaf）经 \IfFontExistsTF
%      自动回退到 TeX 发行版自带的 FandolSong（按文件名经 kpathsea 加载，不依赖
%      系统字体）；英文正文优先 XCharter，等宽字体按 Maple Mono NF → Maple Mono →
%      默认 lmtt 的次序回退。
%
% 用法：\documentclass[11pt,lang=cn]{pkubookv}
%       其余选项原样传给 elegantbook（color / chinesefont 除外，见下）。
% 编译：XeLaTeX 或 LuaLaTeX（中文需要），参考文献用 biber：
%       latexmk -xelatex main.tex
% -----------------------------------------------------------------------------
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{pkubookv}[2026/11/07 v1.0 PKU-style VividBook variant]

% 用户选项原样转发给 elegantbook；color 与 chinesefont 选项不生效：
%   color       —— pkubookv 固定使用北大官方色系（下方 colorlet 覆盖）；
%   chinesefont —— 中文字体统一交给本类的回退链处理。
%   二者会在下方被强制覆盖为 color=blue / chinesefont=nofont（kvoptions
%   后传覆盖生效），如需其他颜色主题请直接改用原版 elegantbook。
\DeclareOption*{\PassOptionsToClass{\CurrentOption}{elegantbook}}
\ProcessOptions\relax
\PassOptionsToClass{color=blue,chinesefont=nofont}{elegantbook}
\LoadClass{elegantbook}

% =============================================================================
% 1. 北京大学官方色系（取自 minimalist-pku-beamer-2026 的 PekingU.sty）
% =============================================================================
\xdefinecolor{peking}{cmyk}{0,1,1,0.45}%        燕园红 ≈ #820010
\xdefinecolor{peking_gold}{cmyk}{0,0.35,0.75,0.05}
\xdefinecolor{peking_blue}{cmyk}{0.6,0.35,0.0,0.4}
\xdefinecolor{peking_darkblue}{cmyk}{1.0,0.6,0.0,0.5}
\xdefinecolor{peking_gray}{cmyk}{0.0,0.0,0.08,0.55}
\xdefinecolor{peking_dirt}{cmyk}{0.0,0.2,0.35,0.3}
\xdefinecolor{peking_orange}{cmyk}{0.0,0.7,1.0,0.0}
\xdefinecolor{peking_green}{cmyk}{0.2,0.0,1.0,0.15}
\xdefinecolor{peking_darkgreen}{cmyk}{0.6,0.5,1.0,0.45}
\xdefinecolor{pantone_gold}{RGB}{135,103,79}
\definecolor{pkubookivory}{RGB}{251,248,241}% 封面标题板底色

% ElegantBook 的颜色接口（结构色/盒色均在排版时取值，此处重定义即可全局生效）
\colorlet{structurecolor}{peking}%        章节标题、页眉页脚、列表编号
\colorlet{main}{peking_blue}%             definition / example / solution 盒
\colorlet{second}{peking}%                theorem / proof / note / remark
\colorlet{third}{peking_orange}%          proposition / assumption / property
\colorlet{coverlinecolor}{peking}%        封面色带
\colorlet{winered}{peking}%               listings 关键字、目录后的链接色
\hypersetup{colorlinks,%
  linkcolor=peking,%
  citecolor=peking_blue,%
  urlcolor=peking_blue,%
  pdfkeywords={Peking University, LaTeX, ElegantBook}}

% =============================================================================
% 2. 字体（移植 Beamer 模板的中文回退机制）
% =============================================================================
\ifcsname setCJKmainfont\endcsname
  % 中文衬线宋体：macOS 用 Songti SC；其他环境自动回退到 TeX 发行版自带的
  % FandolSong（按文件名经 kpathsea 加载，不依赖系统字体）
  \IfFontExistsTF{Songti SC}{%
    \setCJKmainfont{Songti SC}[AutoFakeSlant=0.2]%
    \setCJKsansfont{Songti SC}[AutoFakeSlant=0.2]%
    \setCJKmonofont{Songti SC}%
    \setCJKfamilyfont{zhsong}{Songti SC}[AutoFakeSlant=0.2]%
  }{%
    \setCJKmainfont{FandolSong-Regular}[Extension=.otf,BoldFont=FandolSong-Bold,AutoFakeSlant=0.2]%
    \setCJKsansfont{FandolSong-Regular}[Extension=.otf,BoldFont=FandolSong-Bold,AutoFakeSlant=0.2]%
    \setCJKmonofont{FandolFang-Regular}[Extension=.otf,BoldFont=FandolFang-Regular]%
    \setCJKfamilyfont{zhsong}{FandolSong-Regular}[Extension=.otf,BoldFont=FandolSong-Bold,AutoFakeSlant=0.2]%
  }
  % 书稿还用到黑体/楷体/仿宋字体族，按同样的机制回退
  \IfFontExistsTF{Heiti SC}{%
    \setCJKfamilyfont{zhhei}{Heiti SC}%
  }{\IfFontExistsTF{STHeiti}{%
    \setCJKfamilyfont{zhhei}{STHeiti}%
  }{%
    \setCJKfamilyfont{zhhei}{FandolHei-Regular}[Extension=.otf,BoldFont=FandolHei-Bold]%
  }}
  \IfFontExistsTF{Kaiti SC}{%
    \setCJKfamilyfont{zhkai}{Kaiti SC}%
  }{\IfFontExistsTF{STKaiti}{%
    \setCJKfamilyfont{zhkai}{STKaiti}%
  }{%
    \setCJKfamilyfont{zhkai}{FandolKai-Regular}[Extension=.otf]%
  }}
  \IfFontExistsTF{STFangsong}{%
    \setCJKfamilyfont{zhfs}{STFangsong}%
  }{%
    \setCJKfamilyfont{zhfs}{FandolFang-Regular}[Extension=.otf]%
  }
  \newcommand*{\songti}{\CJKfamily{zhsong}}
  \newcommand*{\heiti}{\CJKfamily{zhhei}}
  \newcommand*{\kaishu}{\CJKfamily{zhkai}}
  \newcommand*{\fangsong}{\CJKfamily{zhfs}}
  % ElegantBook 在类加载时判断 \heiti 是否存在来定义 \cbfseries/\citshape 等，
  % 那时回退链尚未执行，此处重新接上中文习惯（粗体→黑体，斜体/引文→楷体）
  \renewcommand{\cbfseries}{\heiti}
  \renewcommand{\citshape}{\kaishu}
  \renewcommand{\cnormal}{\kaishu}
  \renewcommand{\cfs}{\fangsong}
  % ctex 以 scheme=plain 载入时不会本地化 \today
  \renewcommand{\today}{\the\year 年 \the\month 月 \the\day 日}
  % hyperref \autoref 的中文名称：hyperref 已定义的直接改写，
  % 定理族中 hyperref 未定义的用 \providecommand 补上
  \renewcommand{\equationautorefname}{式}%
  \renewcommand{\figureautorefname}{图}%
  \renewcommand{\tableautorefname}{表}%
  \renewcommand{\theoremautorefname}{定理}%
  \renewcommand{\sectionautorefname}{节}%
  \renewcommand{\subsectionautorefname}{小节}%
  \providecommand*{\definitionautorefname}{定义}%
  \providecommand*{\remarkautorefname}{注}%
  \providecommand*{\exampleautorefname}{例}%
\fi

% 英文衬线：与 Beamer 模板一致优先 XCharter，未安装则保持 ElegantBook 默认的
% TeXGyreTermesX；等宽：Maple Mono NF（静态字族，真实粗/斜体）→ Maple Mono → 默认
\IfFontExistsTF{XCharter}{%
  \setmainfont{XCharter}[Ligatures=TeX]%
}{}
\IfFontExistsTF{Maple Mono NF}{%
  \setmonofont{Maple Mono NF}[Scale=MatchLowercase,Ligatures=TeX]%
}{%
  \IfFontExistsTF{Maple Mono}{%
    \setmonofont{Maple Mono}[Scale=MatchLowercase,Ligatures=TeX]%
  }{}%
}

% =============================================================================
% 3. 页眉页脚：页眉右上角校徽（参照 Beamer 模板 frametitle 的右上角校徽）
% =============================================================================
\fancyhf{}
\fancyhead[L]{\cnormal\small\color{peking!80!black}\leftmark}
\fancyhead[R]{\cnormal\small\color{peking!80!black}\rightmark\hspace{1.2em}%
  \raisebox{-0.22\height}{\includegraphics[height=1.1em]{Figures/PKU-emblem-names.png}}}
\fancyfoot[C]{\color{peking}\small\thepage}
\renewcommand{\headrulewidth}{0.6pt}%
\renewcommand{\headrule}{\color{peking}\hrule width\headwidth height\headrulewidth}
\renewcommand{\footrulewidth}{0pt}
% 章首页（plain 页）不设页眉页脚，由章首照片横幅与标题卡片接管版面
\fancypagestyle{plain}{\renewcommand{\headrulewidth}{0pt}\fancyhf{}\renewcommand{\headrule}{}}

% =============================================================================
% 4. 章首页：整幅照片 + 横跨照片下缘的圆角半透明标题条（VividBook 风格）
% =============================================================================
\newcommand{\pkubook@chapterimage}{Figures/chapter1.jpg}
% 用法：\chapterimage{Figures/xxx.jpg}，作用于下一个（及后续未改动的）章
\newcommand{\chapterimage}[1]{\gdef\pkubook@chapterimage{#1}}

\newlength{\pkubook@bannerheight}
\setlength{\pkubook@bannerheight}{0.5\paperwidth}% A4 上为 105mm，与 2:1 图一致

% 章首页页脚：金色菱形 + 燕园红页码，无页眉
\fancypagestyle{chapterpage}{%
  \fancyhf{}%
  \renewcommand{\headrulewidth}{0pt}%
  \renewcommand{\footrulewidth}{0pt}%
  \fancyfoot[C]{\color{peking_gold}\small$\diamond$\quad
    {\color{peking}\small\thepage}\quad$\diamond$}%
}

% 章首页背景：全幅照片 + 照片下缘燕园红/金色双细线
\newcommand{\pkubook@chapterbanner}{%
  \begin{tikzpicture}[remember picture,overlay]
    \node[anchor=north west,inner sep=0pt,outer sep=0pt]
      at (current page.north west)
      {\includegraphics[width=\paperwidth,height=\pkubook@bannerheight]
        {\pkubook@chapterimage}};
    \fill[peking] ([yshift=-\pkubook@bannerheight]current page.north west)
      rectangle ([yshift=-\pkubook@bannerheight-1.2pt]current page.north east);
    \fill[peking_gold]
      ([yshift=-\pkubook@bannerheight-3.4pt]current page.north west)
      rectangle ([yshift=-\pkubook@bannerheight-4.0pt]current page.north east);
  \end{tikzpicture}%
}

% VividBook 式标题条：一条横贯页面的半透明白色圆角条，章号与章名同行
\newcommand{\pkubook@chaptertitlebar}[1]{%
  \begin{tikzpicture}[remember picture,overlay]
    \node[anchor=west,
          text width=0.78\paperwidth,
          align=left,
          inner sep=4.2mm,
          fill=white, fill opacity=0.84, text opacity=1,
          draw=peking, line width=1.2pt, rounded corners=4mm]
      at ([xshift=0.09\paperwidth,yshift=-92mm]current page.north west) {%
        \def\CJKglue{\hskip 0pt}%
        #1%
      };
  \end{tikzpicture}%
}

\def\@makechapterhead#1{%
  \pkubook@chapterbanner
  \pkubook@chaptertitlebar{%
    {\huge\bfseries\cnormal\color{peking}%
      \IfAppendix{\appendixname\;\thechapter}{\xchaptertitle}}%
    \hspace{4mm}{\color{peking_gold}\large$\blacklozenge$}\hspace{4mm}%
    {\huge\bfseries\color{black}#1}%
  }%
  \par\vspace*{96mm}%
  \thispagestyle{chapterpage}%
}

\def\@makeschapterhead#1{%
  \pkubook@chapterbanner
  \pkubook@chaptertitlebar{%
    {\huge\bfseries\color{black}#1}%
  }%
  \par\vspace*{96mm}%
  \thispagestyle{chapterpage}%
}

% 目录章条目略作强调
\renewcommand{\cftchapfont}{\bfseries\color{peking}}
\renewcommand{\cftchappagefont}{\bfseries\color{peking}}

% =============================================================================
% 5. 封面：全幅校园照片 + 象牙色标题板（与 pkubook 版一致）
%    —— 未指定 \cover{完整封面图} 时启用；\coverphoto 可换照片
% =============================================================================
\newcommand{\pkubook@coverphoto}{Figures/cover.jpg}
% 用法：\coverphoto{Figures/xxx.jpg}；建议使用与 A4 同比例的竖版照片
\newcommand{\coverphoto}[1]{\renewcommand{\pkubook@coverphoto}{#1}}

\let\pkubook@orig@maketitle\maketitle
\renewcommand*{\maketitle}{%
  \ifcsname @cover\endcsname
    % 用户提供了完整封面图：沿用 ElegantBook 原版封面
    \pkubook@orig@maketitle
  \else
    \hypersetup{pageanchor=false}%
    \pagenumbering{Alph}%
    \begin{titlepage}
      \newgeometry{margin=0in}%
      \parindent=0pt
      \begin{tikzpicture}[remember picture,overlay]
        % 全幅照片：只按页宽缩放以保持比例，下 3/8 由象牙色标题板覆盖
        \node[anchor=north west,inner sep=0pt,outer sep=0pt]
          at (current page.north west)
          {\includegraphics[width=\paperwidth]{\pkubook@coverphoto}};
        \fill[pkubookivory] ([yshift=0.375\paperheight]current page.south west)
          rectangle (current page.south east);
        \fill[peking] ([yshift=0.375\paperheight]current page.south west)
          rectangle ([yshift=0.375\paperheight+1.4pt]current page.south east);
        \fill[peking_gold]
          ([yshift=0.375\paperheight+3.4pt]current page.south west)
          rectangle ([yshift=0.375\paperheight+4.0pt]current page.south east);
        % 页眉、页脚处的红色饰带
        \fill[peking] (current page.north west)
          rectangle ([yshift=-2.2mm]current page.north east);
        \fill[peking] (current page.south west)
          rectangle ([yshift=4mm]current page.south east);
        \fill[peking_gold] ([yshift=4mm]current page.south west)
          rectangle ([yshift=4.6mm]current page.south east);
        % 校徽
        \node[anchor=north,inner sep=0pt]
          at ([yshift=-0.655\paperheight]current page.north)
          {\includegraphics[height=11mm]{Figures/PKU-emblem-names.png}};
        % 标题、副标题与花饰；长标题换行后，作者与说明文字依次下移，避免重叠
        \node[anchor=north,text width=0.82\paperwidth,align=center,inner sep=0pt]
          (pkubooktitleblock) at ([yshift=-0.708\paperheight]current page.north) {%
            \def\CJKglue{\hskip 0pt}%
            {\bfseries\fontsize{28}{34}\selectfont\color{peking}%
              \ifcsname @title\endcsname\@title\fi}\\[2.5mm]
            {\color{darkgray}\Large\cnormal
              \ifcsname @subtitle\endcsname\@subtitle\fi}\\[2mm]
            {\color{peking_gold}\adftripleflourishleft\hspace{0.3em}%
              \raisebox{-0.5ex}{\small$\diamond$}\hspace{0.3em}%
              \adftripleflourishright}
          };
        % 作者、单位、日期、版本
        \node[anchor=north,inner sep=0pt]
          (pkubookauthorblock) at ([yshift=-5mm]pkubooktitleblock.south) {%
            \def\CJKglue{\hskip 0pt}%
            \cnormal\large
            \begin{tabular}{@{}c@{}}
              \ifx\@author\empty\else\@author\\[1.2ex]\fi
              \ifcsname @institute\endcsname\@institute\\[1.2ex]\fi
              \ifx\@date\empty\else\@date\\\fi
              \ifcsname @version\endcsname
                {\normalsize\versionname\@version}%
              \fi
            \end{tabular}};
        % 说明文字
        \node[anchor=north,text width=0.78\paperwidth,align=center,inner sep=0pt]
          at ([yshift=-3.5mm]pkubookauthorblock.south) {%
            \def\CJKglue{\hskip 0pt}%
            \small\citshape\color{peking_gray}%
            \ifcsname @extrainfo\endcsname\@extrainfo\fi};
      \end{tikzpicture}%
    \end{titlepage}%
    \restoregeometry
    \thispagestyle{empty}%
  \fi
}

\endinput
